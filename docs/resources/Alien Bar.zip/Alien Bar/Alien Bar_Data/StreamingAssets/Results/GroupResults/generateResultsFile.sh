 #!/usr/bin/env bash
python generateResultsFile.py